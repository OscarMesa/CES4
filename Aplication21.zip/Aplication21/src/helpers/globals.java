/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

import co.edu.polijic.jpql.entidades.Perfil;
import java.util.Date;

/**
 *
 * @author Pablo
 */
public class globals {
    
     static int idUsuario;
     static String nombre;
     static int idPerfil;
     static String contrasena;
     static String correo;
     static Date fechaRegistro;
     static Date fechaNacimiento;
     
     
     public globals(int idUsuario,Perfil idPerfil,String nombre,String correo,Date fechaRegistro,Date fechaNacimiento)
     {
         
     }
    
    
}
