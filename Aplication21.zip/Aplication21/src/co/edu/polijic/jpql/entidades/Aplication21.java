/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.polijic.jpql.entidades;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author omesa
 */
public class Aplication21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Aplication21PU");
        EntityManager em = emf.createEntityManager();
        
    }
}
